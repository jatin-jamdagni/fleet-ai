# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]: F
      - generic [ref=e7]: FLEET AI
    - generic [ref=e8]:
      - generic [ref=e9]:
        - text: MANAGE
        - text: SMARTER.
        - text: MOVE
        - text: FASTER.
      - paragraph [ref=e10]: Real-time GPS fleet management. AI-powered driver assistance. Automated billing.
    - generic [ref=e11]:
      - generic [ref=e12]: GPS TRACKING
      - generic [ref=e13]: AI ASSISTANT
      - generic [ref=e14]: AUTO BILLING
  - generic [ref=e16]:
    - generic [ref=e17]:
      - heading "SIGN IN" [level=1] [ref=e18]
      - paragraph [ref=e19]: Enter your fleet credentials
    - generic [ref=e20]:
      - generic [ref=e21]:
        - generic [ref=e22]: Email Address
        - textbox "manager@fleet.company" [ref=e24]: manager@demo.fleet
      - generic [ref=e25]:
        - generic [ref=e26]: Password
        - textbox "••••••••" [ref=e28]: Manager123!
      - button "SIGN IN" [ref=e29]
    - paragraph [ref=e30]:
      - text: New organisation?
      - link "Register here" [ref=e31] [cursor=pointer]:
        - /url: /register
```